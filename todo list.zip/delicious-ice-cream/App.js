import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, FlatList, Switch } from 'react-native';

export default function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (task.trim() === '') {
      return;
    }
    setTasks([...tasks, { id: Math.random().toString(), content: task }]);
    setTask('');
  };

  const markTaskComplete = (id) => {
    setTasks(tasks.map((task) => {
      if (task.id === id) {
        return { ...task, completed: !task.completed };
      }
      return task;
    }));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ToDoList</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="tìm"
          value={task}
          onChangeText={(text) => setTask(text)}
        />
        <Button title="nhập" onPress={addTask} />
      </View>
      <FlatList
        style={styles.taskList}
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.taskItem}>
            <Text
              style={[
                styles.taskContent,
                item.completed && styles.taskCompleted,
              ]}
            >
              {item.content}
            </Text>
            <Switch
              value={item.completed}
              onValueChange={(value) => markTaskComplete(item.id, value)}
            />
            <Button title="xóa" onPress={() => deleteTask(item.id)} />
           
          </View>
          
          
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ECF4D6',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    marginRight: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#B06161',
  },
  taskList: {
    marginTop: 10,
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  taskContent: {
    flex: 1,
    fontSize: 16,
  },
  taskCompleted: {
    textDecorationLine: 'line-through',
  },
});